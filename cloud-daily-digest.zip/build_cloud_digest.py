#!/usr/bin/env python3
import os, sys, re, time, textwrap, html
import feedparser
import yaml
from datetime import datetime, timedelta
import pytz
from jinja2 import Template

# ==================== 설정 ====================
TIMEZONE = "Asia/Seoul"
SUMMARY_MAX_LEN = 280          # 아이템 요약 길이 제한
DEFAULT_MAX_ITEMS = 10         # 공급자별 최대 아이템 수 (feeds.yaml에서 override 가능)
OUTPUT_DIR = "dist"
MD_FILENAME = "digest.md"
HTML_FILENAME = "index.html"
TEMPLATE_FILE = "template.html"

# ==================== 유틸 ====================
def now_kst():
    tz = pytz.timezone(TIMEZONE)
    return datetime.now(tz)

def human_date(dt):
    return dt.strftime("%Y-%m-%d %H:%M")

def clean_summary(s):
    if not s: return ""
    # Strip HTML tags (rough)
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    if len(s) > SUMMARY_MAX_LEN:
        s = s[:SUMMARY_MAX_LEN-1] + "…"
    return s

def parse_feeds(provider):
    items = []
    for url in provider.get("feeds", []):
        d = feedparser.parse(url)
        for e in d.entries:
            title = e.get("title", "").strip()
            link = e.get("link", "").strip()
            # Prefer published_parsed; fallback to updated_parsed; finally now
            ts = None
            if getattr(e, "published_parsed", None):
                ts = datetime.fromtimestamp(time.mktime(e.published_parsed))
            elif getattr(e, "updated_parsed", None):
                ts = datetime.fromtimestamp(time.mktime(e.updated_parsed))
            else:
                ts = datetime.utcnow()
            # Convert to KST
            ts = pytz.utc.localize(ts).astimezone(pytz.timezone(TIMEZONE)) if ts.tzinfo is None else ts.astimezone(pytz.timezone(TIMEZONE))

            summary = e.get("summary", "") or e.get("description", "")
            summary = clean_summary(summary)
            source = d.feed.title if d and d.get("feed") and d.feed.get("title") else ""

            items.append({
                "title": title,
                "link": link,
                "published_dt": ts,
                "published": ts.strftime("%Y-%m-%d %H:%M"),
                "summary": summary,
                "source": source,
            })
    # 정렬(최신순) 및 상한 적용
    items.sort(key=lambda x: x["published_dt"], reverse=True)
    max_items = provider.get("max_items", DEFAULT_MAX_ITEMS)
    return items[:max_items]

def load_feeds_config(path="feeds.yaml"):
    with open(path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)

def render_markdown(date_str, providers_data):
    md = [f"# Cloud Daily Digest ({date_str} / Asia/Seoul)"]
    for prov in providers_data:
        md.append(f"\n## {prov['name']}\n")
        for it in prov["items"]:
            line = f"- [{it['title']}]({it['link']})  \n  `{it['published']}`"
            if it.get("source"):
                line += f" · *{it['source']}*"
            if it.get("summary"):
                line += f"\n  \n  {it['summary']}"
            md.append(line)
    return "\n".join(md) + "\n"

def render_html(date_str, providers_data, template_path=TEMPLATE_FILE):
    with open(template_path, "r", encoding="utf-8") as f:
        tpl = Template(f.read())
    return tpl.render(date_str=date_str, data=providers_data)

def main():
    cfg = load_feeds_config()
    now = now_kst()
    date_str = now.strftime("%Y-%m-%d")

    providers_data = []
    for p in cfg.get("providers", []):
        items = parse_feeds(p)
        providers_data.append({"name": p["name"], "items": items})

    # 출력
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    md = render_markdown(date_str, providers_data)
    with open(os.path.join(OUTPUT_DIR, MD_FILENAME), "w", encoding="utf-8") as f:
        f.write(md)

    html_out = render_html(date_str, providers_data)
    with open(os.path.join(OUTPUT_DIR, HTML_FILENAME), "w", encoding="utf-8") as f:
        f.write(html_out)

    print(f"Generated: {os.path.join(OUTPUT_DIR, MD_FILENAME)}")
    print(f"Generated: {os.path.join(OUTPUT_DIR, HTML_FILENAME)}")

if __name__ == "__main__":
    main()
